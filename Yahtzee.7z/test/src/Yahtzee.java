import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Yahtzee {
	String playerName;

	int calculateScore(List<Integer> roll, String category) {
		System.out.println("dsd");
		Map<String, Integer> singles = new HashMap<String, Integer>();
		singles.put("ones", 1);
		singles.put("twos", 2);
		singles.put("threes", 3);
		singles.put("fours", 4);
		singles.put("fives", 5);
		singles.put("sixes", 6);
		int score = 0;
		// would prefer to use StringUtils here
		if (singles.containsKey(category)) {
			for (Integer rollEvent : roll) {
				if (rollEvent.compareTo(singles.get(category)) == 0) {
					score += rollEvent;
				}
			}
		}
		// did it in a generic way below
		else if ("Pairs".equals(category)) {
			int max = 0;
			Collections.sort(roll, Collections.reverseOrder());
			for (Integer rollEvent : roll) {
				if (max == rollEvent) {
					score = max * 2;
					break;
				}
				max = rollEvent;
			}
		} else if ("TwoPairs".equals(category)) {
			int firstmaxPair = 0;
			int secondmaxPair = 0;
			boolean firstMaxFound = false;
			boolean secondMaxFound = false;
			Collections.sort(roll, Collections.reverseOrder());
			for (Integer rollEvent : roll) {
				if (!firstMaxFound && firstmaxPair == rollEvent) {
					score = firstmaxPair * 2;
					firstMaxFound = true;
				}
				if (firstMaxFound) {
					if (secondmaxPair == rollEvent
							&& (secondmaxPair != firstmaxPair)) {
						score += (secondmaxPair * 2);
						secondMaxFound = true;
						return score;
					}
					secondmaxPair = rollEvent;
				}
				if (!firstMaxFound) {
					firstmaxPair = rollEvent;
				}
			}
			if (!secondMaxFound) {
				score = 0;
			}
		} else if (("2".equals(category)) || ("3".equals(category))
				|| ("4".equals(category))) {
			int max = 0;
			int matchCount = Integer.parseInt(category);
			Collections.sort(roll, Collections.reverseOrder());
			int tempcount = matchCount;
			for (Integer rollEvent : roll) {
				if (max == rollEvent) {
					matchCount--;
					if (matchCount == 1) {
						score = max * Integer.parseInt(category);
						break;
					}

				} else {
					tempcount = matchCount;
				}
				max = rollEvent;
			}
		} else if ("Small straight".equals(category)) {
			Collections.sort(roll);
			List<Integer> ss = new ArrayList<Integer>();
			ss.add(1);
			ss.add(2);
			ss.add(3);
			ss.add(4);
			ss.add(5);
			if (roll.containsAll(ss)) {
				return 15;
			}

		} else if ("Large straight".equals(category)) {
			Collections.sort(roll);
			List<Integer> ss = new ArrayList<Integer>();
			ss.add(6);
			ss.add(2);
			ss.add(3);
			ss.add(4);
			ss.add(5);
			if (roll.containsAll(ss)) {
				return 20;
			}

		} else if ("Yahtzee".equals(category)) {
			int prev = 0;
			for (Integer rollEvent : roll) {
				if (prev == 0 || prev == rollEvent) {
					prev = rollEvent;
					continue;
				} else
					return 0;
			}
			return 50;

		} else if ("Chance".equals(category)) {
			int sum = 0;
			for (Integer rollEvent : roll) {
				sum += rollEvent;
			}
			return sum;

		}

		return score;
	}

	public static void main(String arg[]) {

		Yahtzee game = new Yahtzee();
		List<Integer> roll = new ArrayList<Integer>();
		roll.add(6);
		roll.add(2);
		roll.add(3);
		roll.add(4);
		roll.add(5);

		// Junits are also available to test all the categories
		int score = game.calculateScore(roll, "Large straight");

		System.out.println("Score:" + score);
	}

}
