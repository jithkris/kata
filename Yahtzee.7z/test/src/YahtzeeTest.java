import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;


public class YahtzeeTest extends TestCase {
	Yahtzee yahtzee;
	List<Integer> roll;
	int score;
	
	@Override
	protected void setUp() throws Exception {
		yahtzee = new Yahtzee();
		roll = new ArrayList<Integer>();
		
	}
	/**
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
		roll.clear();
		yahtzee = null;
		roll = null;
	}
	public void testCategoryOnes() {
		roll.add(6);
		roll.add(1);
		roll.add(3);
		roll.add(1);
		roll.add(5);
		score=yahtzee.calculateScore(roll, "ones");
		assertEquals(2, score);
		
	}
	public void testCategoryTwos() {
		roll.add(2);
		roll.add(1);
		roll.add(2);
		roll.add(2);
		roll.add(5);
		score=yahtzee.calculateScore(roll, "twos");
		assertEquals(6, score);
		
	}
	public void testCategoryThrees() {
		roll.add(2);
		roll.add(1);
		roll.add(3);
		roll.add(2);
		roll.add(3);
		score=yahtzee.calculateScore(roll, "threes");
		assertEquals(6, score);
		
	}
	public void testCategoryFours() {
		roll.add(2);
		roll.add(4);
		roll.add(4);
		roll.add(2);
		roll.add(4);
		score=yahtzee.calculateScore(roll, "fours");
		assertEquals(12, score);
		
	}
	public void testCategoryFives() {
		roll.add(2);
		roll.add(1);
		roll.add(2);
		roll.add(2);
		roll.add(5);
		score=yahtzee.calculateScore(roll, "fives");
		assertEquals(5, score);
		
	}
	public void testCategorySixes() {
		roll.add(2);
		roll.add(1);
		roll.add(6);
		roll.add(6);
		roll.add(6);
		score=yahtzee.calculateScore(roll, "sixes");
		assertEquals(18, score);
		
	}
	public void testYahtzee() {
		roll.add(2);
		roll.add(2);
		roll.add(2);
		roll.add(2);
		roll.add(2);
		score=yahtzee.calculateScore(roll, "Yahtzee");
		assertEquals(50, score);
		
	}
	public void testChance() {
		roll.add(2);
		roll.add(1);
		roll.add(4);
		roll.add(2);
		roll.add(1);
		score=yahtzee.calculateScore(roll, "Chance");
		assertEquals(10, score);
		
	}

}
